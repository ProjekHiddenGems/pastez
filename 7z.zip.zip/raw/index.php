<?php
$file = $_GET['file'] ?? '';
$path = "raw/{$file}";

if (file_exists($path)) {
    $lines = file($path, FILE_IGNORE_NEW_LINES);
    if (strpos($lines[0], 'EXPIRE:') === 0) {
        $expire_at = (int)substr($lines[0], 7);
        if ($expire_at > 0 && time() > $expire_at) {
            unlink($path);
            die("⛔ File ini telah kedaluwarsa dan telah dihapus.");
        }
        array_shift($lines); // Hapus baris EXPIRE agar tidak ditampilkan
    }

    $content = implode("\n", $lines);
    echo nl2br(htmlspecialchars($content));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>403 Forbidden</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      height: 100vh;
      background: linear-gradient(120deg, #0d0d0d, #1a1a1a);
      display: flex;
      justify-content: center;
      align-items: center;
      backdrop-filter: blur(10px);
      color: #fff;
    }

    .glass-card {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      padding: 3rem 2rem;
      border-radius: 16px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.5);
      text-align: center;
      max-width: 400px;
      width: 90%;
    }

    .glass-card h1 {
      font-size: 5rem;
      margin: 0;
      color: #ff4c4c;
    }

    .glass-card p {
      margin: 1rem 0 2rem;
      font-size: 1rem;
      color: #ccc;
    }

    .glass-card a {
      text-decoration: none;
      padding: 0.75rem 1.5rem;
      border-radius: 8px;
      background: #00ffe0;
      color: #0f0f0f;
      font-weight: bold;
      border: none;
      transition: all 0.3s ease-in-out;
    }

    .glass-card a:hover {
      background: #00ccb5;
    }

    .footer-note {
      margin-top: 2rem;
      font-size: 0.8rem;
      color: #666
     
    }
    
.tujuhjet a {
  text-decoration: none; /* Hilangkan garis bawah */
  color: inherit;         /* Gunakan warna teks dari induk */
  background: none;       /* Tidak ada background */
  border: none;           /* Hilangkan border */
  outline: none;          /* Hilangkan outline saat fokus */
  cursor: pointer;        /* Tetap tampil seperti link */
}

.tujuhjet:hover,
.tujuhjet:active,
.tujuhjet:visited,
.tujuhjet:focus {
  text-decoration: none;
  color: inherit;
  background: none;
  border: none;
  outline: none;
}

  </style>
</head>
<body>
  <div class="glass-card">
    <h1>403</h1>
    <p>Jangan aneh aneh deh bro !</p>
    <a href="/">🔙 Kembali ke Beranda</a>
 <div class="footer-note">© 2025 | Pastejet<br><a href="https://pastejet.xyz" style="color:yellow; text-decoration: none; background: none; border: none; outline: none; cursor: pointer;">www.pastejet.xyz</font></a></div></div>
</div>
 </body>
</html>
