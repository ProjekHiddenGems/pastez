<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="UTF-8">
<title>Pastejet Tools | Encode, Decode, Obfuscator, Hash Tools</title>
<meta name="description" content="Gunakan tools online dari PasteJet untuk encode, decode, obfuscator PHP, text reverse, dan hash generator. Gratis dan cepat!">
<meta name="keywords" content="Tools csrf, 7z, tools online, php obfuscator, base64, url encode decode, hash generator, text reverser, encoder decoder, tools gratis, pastejet, cyber tools, online encoder">
<meta name="author" content="PasteJet">
<meta name="robots" content="index, follow">
<link rel="canonical" href="https://pastejet.xyz/tools/">


<meta property="og:title" content="PasteJet Tools | Encode, Decode, Obfuscator, Hash Tools">
<meta property="og:description" content="Kumpulan tools online buatan 7z : encode, decode, obfuscator, reverse, dan hash generator. Cocok untuk keperluan developer dan hacker tools.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://pastejet.xyz/tools/">
<meta property="og:image" content="https://i.imgur.com/G8Nby02.png">


<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="PasteJet Tools">
<meta name="twitter:description" content="Kumpulan tools online dari 7z seperti encode, decode, PHP obfuscator, dan hash generator.">
<meta name="twitter:image" content="https://i.imgur.com/G8Nby02.png">

<style>
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
    overflow-x: hidden;
    max-width: 100%;
  }

  body {
    display: flex;
    flex-direction: column;
    font-family: 'Segoe UI', sans-serif;
    background-color: #121212;
    color: #e0e0e0;
  }

  .wrapper {
    flex: 1;
    display: flex;
    flex-direction: column;
  }

  header {
    background-color: #1e1e2f;
    padding: 20px;
    text-align: center;
    font-size: 24px;
    color: #00cec9;
  }

  nav {
    background-color: #2b2b3c;
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    padding: 10px;
    gap: 10px;
  }

  nav a {
    color: #dcdcdc;
    text-decoration: none;
    font-weight: bold;
    padding: 8px 12px;
    border-radius: 5px;
  }

  nav a:hover, nav a.active {
    color: #00cec9;
    background-color: #1e1e2f;
  }

  main {
    flex: 1;
  }

  section {
    padding: 30px;
    max-width: 800px;
    margin: 0 auto;
    box-sizing: border-box;
  }

  h2 {
    border-bottom: 1px solid #444;
    padding-bottom: 10px;
  }

  textarea, input, select {
    width: 100%;
    padding: 12px;
    margin-top: 10px;
    background-color: #1f1f2e;
    color: #eee;
    border: 1px solid #333;
    border-radius: 5px;
    font-family: Consolas, monospace;
    box-sizing: border-box;
  }

  input[type="submit"] {
    background-color: #00b894;
    cursor: pointer;
    font-weight: bold;
    margin-top: 15px;
    border: none;
    border-radius: 5px;
    transition: 0.3s;
  }

  input[type="submit"]:hover {
    background-color: #00cec9;
  }

  .result {
    margin-top: 15px;
    background-color: #1f1f2e;
    border: 1px solid #00b894;
    padding: 15px;
    border-radius: 5px;
    color: #c3f3e2;
    white-space: pre-wrap;
    word-wrap: break-word;
    box-sizing: border-box;
  }

  footer {
    background-color: #1e1e2f;
    color: #aaa;
    text-align: center;
    padding: 15px 0;
    font-size: 14px;
  }
  
   img {
    display: block;
    margin: auto;
    width: 180px;
    filter: drop-shadow(0 0 10px #00fff7);
}


  /* ======================= */
  /* Responsive Mobile Style */
  /* ======================= */
  @media screen and (max-width: 768px) {
    header {
      font-size: 20px;
      padding: 15px;
    }

    nav {
      flex-direction: column;
      align-items: center;
    }

    nav a {
      margin: 5px 0;
    }

    section {
      padding: 20px 15px;
      width: 100%;
    }

    textarea, input, select {
      font-size: 1rem;
      padding: 10px;
    }

    input[type="submit"] {
      width: 100%;
    }

    .result {
      font-size: 0.95rem;
      padding: 12px;
    }
    
    img {
    display: block;
    margin: auto;
    width: 100px;
    filter: drop-shadow(0 0 10px #00fff7);
}
    
  }
  



</style>

</head>
<body>

<div class="wrapper">
  <header>
   <div style="display: flex; justify-content: center; align-items: center; gap: 20px;">
  <img src="https://i.imgur.com/G8Nby02.png" alt="7z Logo">
  <h2>x</h2>
  <img src="https://i.imgur.com/vlTtm4X.png" alt="TAB Logo">
</div>


    TOOLS LAINNYA by 7z
  </header>

  <nav>
  <a href="?">Home</a>
  <a href="?Tools=Toolslain&menu=encode" class="<?= ($_GET['menu'] ?? '') === 'encode' ? 'active' : '' ?>">Encode & Decode</a>
  <a href="?Tools=Toolslain&menu=obfuscator" class="<?= ($_GET['menu'] ?? '') === 'obfuscator' ? 'active' : '' ?>">PHP Obfuscator</a>
  <a href="?Tools=Toolslain&menu=reverse" class="<?= ($_GET['menu'] ?? '') === 'reverse' ? 'active' : '' ?>">Text Reverser</a>
  <a href="?Tools=Toolslain&menu=hash" class="<?= ($_GET['menu'] ?? '') === 'hash' ? 'active' : '' ?>">Hash Generator</a>
  <a href="https://pastejet.xyz/">PasteJet</a>
</nav>


  <main>
    <?php
$menu = $_GET['menu'] ?? '';


if ($menu === 'encode') {
    ?>
    <section>
      <h2>Encode & Decode</h2>
     <form method="post">
    <textarea name="code" placeholder="Masukkan Kode Disini..."><?php echo htmlspecialchars($_POST['code'] ?? ''); ?></textarea>

    <select name="ope" required>
        <option value="">-- Pilih Metode --</option>
        <option value="urlencode">url</option>
        <option value="base64">base64</option>
        <option value="ur">convert_uu</option>
        <option value="json">json</option>
        <option value="gzinflates">gzinflate - base64</option>
        <option value="str2">str_rot13 - base64</option>
        <option value="gzinflate">str_rot13 - gzinflate - base64</option>
        <option value="gzinflater">gzinflate - str_rot13 - base64</option>
        <option value="gzinflatex">gzinflate - str_rot13 - gzinflate - base64</option>
        <option value="gzinflatew">complex mixed chain</option>
        <option value="str">str_rot13 - gzinflate - str_rot13 - base64</option>
        <option value="url">base64 - gzinflate - str_rot13 - convert_uu - gzinflate - base64</option>
    </select>

    <input type="submit" name="submit" value="Encode" />
    <input type="submit" name="submits" value="Decode" />
</form>

<?php
$text = $_POST['code'] ?? '';
$op = $_POST['ope'] ?? '';
$encodeBtn = $_POST['submit'] ?? null;
$decodeBtn = $_POST['submits'] ?? null;
$codi = '';

if ($encodeBtn) {
    switch ($op) {
        case 'base64': $codi = base64_encode($text); break;
        case 'str': $codi = base64_encode(str_rot13(gzdeflate(str_rot13($text)))); break;
        case 'json': $codi = json_encode(utf8_encode($text)); break;
        case 'gzinflate': $codi = base64_encode(gzdeflate(str_rot13($text))); break;
        case 'gzinflater': $codi = base64_encode(str_rot13(gzdeflate($text))); break;
        case 'gzinflatex': $codi = base64_encode(gzdeflate(str_rot13(gzdeflate($text)))); break;
        case 'gzinflatew':
            $codi = base64_encode(gzdeflate(str_rot13(rawurlencode(
                gzdeflate(convert_uuencode(base64_encode(str_rot13(
                    gzdeflate(convert_uuencode(rawurldecode(str_rot13($text))))
                ))))
            ))));
            break;
        case 'gzinflates': $codi = base64_encode(gzdeflate($text)); break;
        case 'str2': $codi = base64_encode(str_rot13($text)); break;
        case 'urlencode': $codi = rawurlencode($text); break;
        case 'ur': $codi = convert_uuencode($text); break;
        case 'url': $codi = base64_encode(gzdeflate(convert_uuencode(str_rot13(gzdeflate(base64_encode($text)))))); break;
        default: $codi = "Invalid encode operation."; break;
    }
    echo "<div style='color:cyan;' class='output-label'>&nbsp;Hasil :</div>";
    echo "<div class='output'><textarea readonly>" . htmlentities($codi) . "</textarea></div>";
}

if ($decodeBtn) {
    try {
        switch ($op) {
            case 'base64': $codi = base64_decode($text); break;
            case 'str': $codi = str_rot13(gzinflate(str_rot13(base64_decode($text)))); break;
            case 'json': $codi = utf8_decode(json_decode($text)); break;
            case 'gzinflate': $codi = str_rot13(gzinflate(base64_decode($text))); break;
            case 'gzinflater': $codi = gzinflate(str_rot13(base64_decode($text))); break;
            case 'gzinflatex': $codi = gzinflate(str_rot13(gzinflate(base64_decode($text)))); break;
            case 'gzinflatew':
                $codi = str_rot13(rawurldecode(convert_uudecode(gzinflate(str_rot13(
                    base64_decode(convert_uudecode(gzinflate(rawurldecode(
                        str_rot13(gzinflate(base64_decode($text)))
                    ))))
                )))));
                break;
            case 'gzinflates': $codi = gzinflate(base64_decode($text)); break;
            case 'str2': $codi = str_rot13(base64_decode($text)); break;
            case 'urlencode': $codi = rawurldecode($text); break;
            case 'ur': $codi = convert_uudecode($text); break;
            case 'url': $codi = base64_decode(gzinflate(str_rot13(convert_uudecode(gzinflate(base64_decode($text)))))); break;
            default: $codi = "Invalid decode operation."; break;
        }
        echo "<div class='output-label'>Hasil:</div>";
        echo "<div class='output'><textarea readonly>" . htmlentities($codi) . "</textarea></div>";
    } catch (Exception $e) {
        echo "<p class='error'>Error decoding input: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
}
?>

    </section>
    <?php
} elseif ($menu === 'reverse') {
    ?>
    <section>
      <h2>Text Reverser</h2>
      <form method="post">
        <textarea name="reverseText" placeholder="Masukkan teks untuk reverse..."><?php echo htmlspecialchars($_POST['reverseText'] ?? '') ?></textarea>
        <input type="submit" name="reverseBtn" value="Reverse Text">
      </form>
      <?php
      if (isset($_POST['reverseBtn'])) {
          $reversed = strrev($_POST['reverseText'] ?? '');
          echo "<div class='result'><strong>Reversed Text:</strong><br>$reversed</div>";
      }
      ?>
    </section>
    <?php
} elseif ($menu === 'hash') {
    ?>
    <section>
      <h2>Hash Generator</h2>
      <form method="post">
        <input type="text" name="hashInput" placeholder="Masukkan Hash..." value="<?php echo htmlspecialchars($_POST['hashInput'] ?? '') ?>">
        <select name="hashType">
          <option value="md5">MD5</option>
          <option value="sha1">SHA1</option>
          <option value="sha256">SHA256</option>
        </select>
        <input type="submit" name="hashBtn" value="Generate Hash">
      </form>
      <?php
      if (isset($_POST['hashBtn'])) {
          $text = $_POST['hashInput'] ?? '';
          $algo = $_POST['hashType'] ?? 'md5';
          $hash = hash($algo, $text);
          echo "<div class='result'><strong>$algo Hash:</strong><br>$hash</div>";
      }
      ?>


    </section>
<?php
} elseif ($menu === 'obfuscator') {
?>
<section>
  <h2>PHP Obfuscator</h2>
  <form method="post">
    <textarea name="obf_code" placeholder="Masukkan kode PHP..."><?php echo htmlspecialchars($_POST['obf_code'] ?? '') ?></textarea>
    <input type="submit" name="obfBtn" value="Obfuscate">
  </form>

  <?php
if (isset($_POST['obfBtn'])) {
    $inputCode = $_POST['obf_code'] ?? '';

    // Hapus tag PHP agar tidak dobel
    $inputCode = preg_replace('/<\?php|\?>/', '', $inputCode);

    // Kompres dan encode input
    $encoded = base64_encode(gzdeflate($inputCode));

    // Buat isi Lix berdasarkan input — misalnya dari hash
    $lixValue = '==' . substr(bin2hex(sha1($inputCode, true)), 0, 24); // hex 24 char

    // Susun hasil obfuscasi
    $final = "<?php\n";
    $final .= "\$Cyto = \"$encoded\";\n";
    $final .= "\$Lix = \"$lixValue\";\n";
    $final .= "eval(htmlspecialchars_decode(gzinflate(base64_decode(\$Cyto))));\n";
    $final .= "exit;\n?>";

    // Tampilkan hasil
    echo "<div class='result'><strong>Hasil Obfuscate:</strong><br><textarea readonly style='min-height:200px; width:100%;'>" .
        htmlspecialchars($final) .
        "</textarea></div>";
}
?>


</section>


    <?php
} else {
    echo "<section><h2>Silahkan pilih menu Tools diatas !</h2><p style='text-align:center;'>TAB x 7z</p></section>";
}
?>

  </main>
</div>

<footer>
    Dibuat oleh <span style="color: yellow;">7z</span> &copy; <?= date('Y') ?> — <span style="color: orange;">www.pastejet.xyz</span>
</footer>
</body>
</html>

