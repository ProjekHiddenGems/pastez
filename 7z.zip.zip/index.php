<?php
$dir = 'raw';
if (!is_dir($dir)) {
    mkdir($dir, 0777, true);
}


foreach (glob("$dir/*.meta") as $meta_file) {
    $data = json_decode(file_get_contents($meta_file), true);
    $expire_time = $data['expire'] ?? 0;

    if ($expire_time > 0 && time() >= $expire_time) {
        $original_file = str_replace('.meta', '', $meta_file);
        @unlink($original_file);
        @unlink($meta_file);
    }
}

$download_link = '';
$preview_content = '';
$submitted = false;
$expire_info = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = $_POST['content'] ?? '';
    $expire_days = (int)($_POST['expire'] ?? 0);

    if (!empty(trim($content))) {
        $filename = bin2hex(random_bytes(5)) . '7z';
        $path = "$dir/$filename.txt";
        file_put_contents($path, $content);

        
        $expire_timestamp = ($expire_days > 0) ? time() + ($expire_days * 86400) : 0;
        file_put_contents("$path.meta", json_encode(['expire' => $expire_timestamp]));

        $download_link = "$dir/$filename";
        $preview_content = htmlspecialchars($content);
        $submitted = true;

        if ($expire_timestamp > 0) {
            $expire_info = '<p style="color:#ccc; margin-top:10px;">Expired: ' . date('d M Y H:i', $expire_timestamp) . '</p>';
        } else {
            $expire_info = '<p style="color:#ccc; margin-top:10px;">Tidak pernah expired</p>';
        }
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <base href="https://pastejet.xyz/"/>
  <title>PasteJet - #1 paste tool since 2005!</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="https://pastejet.xyz/7z.png"/>
<link rel="canonical" href="https://pastejet.xyz/"/> 
  <meta name="description" content="PasteJet membantu Anda menyimpan, mencari, dan mengatur semua yang Anda salin di semua perangkat Anda. Cobalah secara gratis. Desain tidak mencolok yang menyatu dengan alur kerja Anda.">
  <meta name="keywords" content="Paste, Paste text, Pastebin, Paste raw, raw, PasteJet, pastebin, penyimpan teks, salin tempel online, clipboard online, catatan instan, paste online, raw text, tools csrf, tools , alat web">
  <meta name="author" content="7z & Team Anti Baper">
  <meta name="rating" content="general">
  <meta name="language" content="id">
  <meta name="geo.region" content="ID">
  <meta name="geo.placename" content="Indonesia">
  <meta property="og:title" content="PasteJet - Alat Penyimpan Teks oleh 7z">
  <meta property="og:description" content="PasteJet adalah layanan untuk menyimpan dan membagikan teks secara instan, gratis, dan tanpa ribet. Cocok untuk developer, catatan rahasia, dan clipboard online.">
  <meta property="og:image" content="https://pastejet.xyz/tab.png">
  <meta property="og:url" content="https://pastejet.xyz/index"> 
  <meta property="og:type" content="website">

 
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="PasteJet - Alat Simpan Salinan Teks">
  <meta name="twitter:description" content="Simpan, salin, dan bagikan teks dengan cepat lewat PasteJet. Desain clean dan ringan.">
  <meta name="twitter:image" content="https://pastejet.xyz/tab.png">


  <link href="https://fonts.googleapis.com/css2?family=Fira+Code&family=Inter:wght@400;600&display=swap" rel="stylesheet">

  <style>
    :root {
      --bg: #0d0f14;
      --glass: rgba(255, 255, 255, 0.05);
      --border: rgba(255, 255, 255, 0.15);
      --accent: #3bc8ff;
      --accent-hover: #5bd5ff;
      --text: #f4f4f5;
      --subtle: #9ca3af;
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: 'Inter', sans-serif;
      background: var(--bg);
      color: var(--text);
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 2rem 1rem;
      min-height: 100vh;
    }

    .header {
      text-align: center;
      margin-bottom: 2.5rem;
    }

    .header img {
      width: 150px;
      margin-bottom: 1rem;
      filter: drop-shadow(0 0 6px var(--accent));
    }

    .header h1 {
      font-size: 2rem;
      font-weight: 600;
      color: var(--accent);
    }

    .card {
  background: var(--glass);
  border: 1px solid var(--border);
  backdrop-filter: blur(10px);
  padding: 2.5rem;
  border-radius: 16px;
  width: 100%;
  max-width: 1500px; 
  box-shadow: 0 0 20px rgba(0,0,0,0.2);
}

textarea {
  width: 100%;
  height: 500px; 
  background: transparent;
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.5rem; 
  color: var(--text);
  font-family: 'Fira Code', monospace;
  font-size: 1.1rem; 
  resize: vertical;
  margin-bottom: 1.5rem;
  line-height: 1.6;
}


    button {
      background: var(--accent);
      color: #000;
      font-weight: 600;
      padding: 12px 24px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.3s ease;
    }

    button:hover {
      background: var(--accent-hover);
    }

    .output-link {
      margin-top: 2rem;
      text-align: center;
      animation: fadeIn 0.5s ease;
    }

    .output-link a {
      color: var(--accent);
      text-decoration: none;
      font-weight: 600;
      word-break: break-all;
    }

    .copy-btn {
      margin-top: 0.8rem;
      padding: 8px 16px;
      background: transparent;
      border: 1px solid var(--accent);
      color: var(--accent);
      border-radius: 8px;
      font-size: 0.95rem;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .copy-btn:hover {
      background-color: var(--accent);
      color: #0d1117;
    }

    .copied-msg {
      margin-top: 8px;
      font-size: 0.85rem;
      color: #16e07c;
      display: none;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    footer {
      margin-top: 2rem;
      font-size: 0.85rem;
      color: var(--subtle);
    }
      .preview-wrapper {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 1rem;
  }

  .preview-box {
  position: relative;
  background: var(--glass);
  border: 1px solid var(--border);
  padding: 2.5rem 1.5rem 1.5rem 1.5rem; 
  border-radius: 12px;
  font-family: 'Fira Code', monospace;
  white-space: pre-wrap;
  word-break: break-word;
  line-height: 1.5;
  overflow-wrap: break-word;
}

.preview-header {
  position: absolute;
  top: 10px;
  right: 12px;
  display: flex;
  gap: 8px;
  z-index: 2;
}

.preview-header button {
  padding: 4px 10px;
  font-size: 0.75rem;
  background: var(--accent);
  border-radius: 6px;
  color: #000;
  border: none;
  cursor: pointer;
  transition: background 0.3s ease;
}

.preview-header button:hover {
  background: var(--accent-hover);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
}

.new-paste-btn {
  background: var(--glass);
  color: var(--accent);
  border: 1px solid var(--accent);
  padding: 6px 14px;
  font-size: 0.8rem;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s ease;
  text-decoration: none;
}

.new-paste-btn:hover {
  background: var(--accent);
  color: #000;
}

.preview-header {
  display: flex;
  gap: 8px;
}

.preview-header button {
  padding: 5px 10px;
  font-size: 0.75rem;
  background: var(--accent);
  border-radius: 6px;
  color: #000;
  border: none;
  cursor: pointer;
  transition: background 0.3s ease;
}

.preview-header button:hover {
  background: var(--accent-hover);
}

.header-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid var(--border);
}

.header-bar h1 {
  font-size: 1.5rem;
  color: var(--accent);
  margin: 0;
}

.tools-link {
  font-size: 0.95rem;
  color: var(--accent);
  text-decoration: none;
  padding: 6px 12px;
  background: var(--glass);
  border: 1px solid var(--accent);
  border-radius: 8px;
  transition: 0.3s ease;
}

.tools-link:hover {
  background: var(--accent);
  color: #000;
}

img {
    display: block;
    margin: auto;
    width: 180px;
    filter: drop-shadow(0 0 10px #00fff7);
}

.expire-form {
  margin-bottom: 24px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  padding: 10px 18px;
  background: linear-gradient(135deg, #1f1f2e, #1b1b28);
  border: 1px solid #2f2f3f;
  border-radius: 10px;
  box-shadow: 0 0 12px rgba(0, 255, 200, 0.07);
  max-width: 280px;
  font-family: 'Segoe UI', Tahoma, sans-serif;
  transition: background 0.3s ease-in-out;
}

.expire-form:hover {
  background: linear-gradient(135deg, #26263a, #1f1f30);
  box-shadow: 0 0 15px rgba(0, 255, 200, 0.12);
}

.expire-form label {
  color: #00ffc3;
  font-weight: 600;
  font-size: 15px;
  text-shadow: 0 0 4px rgba(0, 255, 200, 0.2);
}

.expire-form select {
  background-color: #2b2b3c;
  color: #ffffff;
  border: 1px solid #00b894;
  padding: 7px 12px;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  font-family: Consolas, monospace;
  transition: all 0.2s ease;
  cursor: pointer;
}

.expire-form select:focus {
  outline: none;
  border-color: #00ffc3;
  box-shadow: 0 0 8px #00ffc3;
  background-color: #32324b;
}

.expire-form select:hover {
  background-color: #32324b;
}

@media (max-width: 768px) {
  body {
    padding: 1rem 0.5rem;
  }

  .header img {
    width: 120px;
    margin-bottom: 0.5rem;
  }

  .header h1 {
    font-size: 1.5rem;
  }

  .card {
    padding: 1.2rem;
  }

  textarea {
    height: 300px;
    padding: 1rem;
    font-size: 1rem;
  }

  .preview-wrapper {
    flex-direction: column;
    align-items: stretch;
  }

  .preview-box {
    padding: 1.5rem 1rem 1rem 1rem;
    font-size: 0.9rem;
  }

  .preview-header {
    top: 6px;
    right: 6px;
    gap: 4px;
  }

  .preview-header button {
    padding: 4px 8px;
    font-size: 0.7rem;
  }

  .header-bar {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }

  .header-bar h1 {
    font-size: 1.3rem;
  }

  .tools-link {
    padding: 5px 10px;
    font-size: 0.85rem;
  }

  .new-paste-btn {
    width: 100%;
    text-align: center;
    font-size: 0.85rem;
    padding: 10px;
    margin-top: 0.5rem;
  }

  button {
    width: 100%;
    font-size: 1rem;
  }

  .output-link {
    font-size: 0.9rem;
    word-break: break-word;
  }

  img {
    width: 140px;
  }
}

  </style>
</head>
<body>

<div style="display: flex; justify-content: center; align-items: center; gap: 20px;">
  <img src="https://i.imgur.com/G8Nby02.png" alt="7z Logo">
  <h2>x</h2>
  <img src="https://i.imgur.com/vlTtm4X.png" alt="TAB Logo">
</div>


<?php if (!$submitted): ?>
  <center><h1>PasteJet</h1></center>
  <div class="header-bar">
  <a href="tools" class="tools-link"> Tools Lain</a>
</div>

  <div class="card">
    <form method="POST">
      <div class="expire-form">
  <label for="expire">Expire :</label>
  <select name="expire" id="expire">
    <option value="1">1 Hari</option>
    <option value="3">3 Hari</option>
    <option value="7">7 Hari</option>
    <option value="30">30 Hari</option>
    <option value="0">Tidak Pernah</option>
  </select>
  
</div>
    
      <textarea name="content" placeholder="Tulis sesuatu di sini..." autofocus required></textarea>
      <center><button type="submit">🚀 Crot ah!</button></center>
    </form>
  </div>
  
<?php else: ?>
<div class="card">
  <div class="card-header">
    <a href="" class="new-paste-btn">➕ Paste Baru</a>    
    <center> <?= $expire_info ?></center>
    <div class="preview-header">
      <button onclick="window.open('<?= htmlspecialchars($download_link) ?>', '_blank')"> Raw</button>
      <button onclick="window.location.href='<?= htmlspecialchars($download_link) ?>'"> Download</button>
      <button onclick="copyToClipboard('<?= htmlspecialchars("https://pastejet.xyz/$download_link") ?>')"> Copy</button>
    </div>
  </div>

  <div class="preview-box">
    <?= $preview_content ?>
  </div>
</div>


<?php endif; ?>

<footer>
  Dibuat oleh <span style="color: yellow;">7z</span> &copy; <?= date('Y') ?>  <span style="color: orange;">PasteJet</span>
</footer>

<script>
  function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
      alert("Link berhasil disalin!");
    });
  }
</script>

</body>
</html>